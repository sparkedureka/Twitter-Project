//case class Department(val dept_name:String)
case class Department(dept_name:String) {
	override def toString = s"Department: $dept_name"
}

object CaseRunner extends App {
// 	val Finance = new Department("Finance")
	val Finance = Department("Finance")

//	println(Finance.toString())
//	println(Finance.toString)
	println(Finance)

//	val Finance2 = new Department("Finance")
	val Finance2 = Department("Finance")

	println(Finance == Finance2)

	println(Finance.hashCode == Finance2.hashCode)

	val hardware = Finance.copy(dept_name="Hardware")
	println(hardware)
}

