object ReservTest extends App {
	println(Reservations.newReservationnum) 
}


object Reservations {
 	private var lastnum = 0
	def newReservationnum () = {
		lastnum += 1
		lastnum
	}
}
