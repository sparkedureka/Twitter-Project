class salary (val sal:Int, val mode:String, val currency:String) {
	def getSalary():String = "Your Salary is " + sal 
//	private def salcode = sal + mode + currency
}

class emp1(val name:String, val dept:String, override val sal:Int, override val mode:String, override val currency:String) 
							extends	salary(sal, mode,currency) {
	override def getSalary():String = "Your Salary is " + sal + " " + currency +  " credited via " + mode 
	def getSalary2 = name + " " + super.getSalary + " " + currency +  " credited via " + mode

//	override def salcode = "Your Salary is " + sal + " " + currency +  " credited via " + mode
}

object salrunner extends App {
	val Adarsh = new emp1("Adarsh","Technology",6000,"Bank Xfer","EUROs") 
	println(Adarsh.sal)
	println(Adarsh.getSalary)
	val salamount = new salary(8000,"CASH","DOLLARS")
	println(Adarsh.getSalary2)
	println(salamount.getSalary)
	
}	
