object TestRunner {
	def main(args:Array[String]):Unit = {
		println("Scala Edition")
		val Allan = new Employee("Allan", "Chin")
        	println(Allan.firstname)
		println(Allan.lastname)
		Allan.firstname_$eq("Allan Sr.")
		Allan.lastname_$eq("Donald")
		Allan.lastname = "Donald Trump"
		println(Allan.firstname + " " + Allan.lastname)
		//println(Allan.lastname)
	}
}
