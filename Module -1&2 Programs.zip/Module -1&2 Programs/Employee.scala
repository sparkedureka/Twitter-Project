class Employee(var firstname:String, var lastname:String)
//class Employee(val firstname:String, var lastname:String)
//scala programmers dont want to use varr, use below annotation which will generate java style getter and setter

//import scala.beans.BeanProperty

//class Employee(@BeanProperty var firstname:String,@BeanProperty val lastname:String) 
