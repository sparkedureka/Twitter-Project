import scala.beans.BeanProperty

object TestPerson3 extends App {
       val Virat = new Person3(Age=27,Name="Virat Kohli")
       println(Virat.Name + " is of Age " + Virat.Age + " and he is a " + Virat.Title)
       println(Virat.Name + " is of Age " + Virat.Age + " and he is a " + Virat.Title + " who loves " + Virat.Hobbies)
}

class Person3(@BeanProperty val Name:String,
              @BeanProperty var Age:Int,
	      val Hobbies:String = "Bollywood Movies",
              val Title:String = "Sports Person") {
//      def this(Name:String,Age:Int,Hobbies:String) = this(Name:String,Age:Int,Hobbies:String,"Sports Person")
//      def this(Name:String,Age:Int) = this(Name:String,Age:Int,Hobbies:String)
}























