import scala.beans.BeanProperty

object TestPerson extends App {
       val Virat = new Person1("Virat Kohli",27) 		
       println(Virat.Name + " is of Age " + Virat.Age)
       Virat.setAge(30)
       println(Virat.Age)
       Virat.setAge_(35)
       println(Virat.Age)	


//       val Sachin = new Person11
//       println(Sachin.age)
//       println(Sachin.age_(45))
//       println(Sachin.age)	
//       println(Sachin.age_(25))
//       println(Sachin.age)
}

class Person1(@BeanProperty val Name:String,@BeanProperty var Age:Int) {
	def setAge_(Age1:Int) = {
		if (Age1 > Age) Age = Age1;
	}
}

//class Person11 {
//	private var privateage = 0
//	def age = privateage
//	def age_(newage:Int) = {if (newage > privateage) {
//							privateage = newage
//				                        println("age set") 
//							 }
//				else {
//					println("Age is less than current")
//				     }
//				}
//} 
