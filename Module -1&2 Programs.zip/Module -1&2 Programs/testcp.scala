class SecretAgentsl(private var AgentNamel:String) {
//        def shootl(n:Int) = {
//                SecretAgents.decrementbullets(n)
//                println("Agent " + AgentNamel + " shot " + n + " bullets!")
//        }
//	override def AgentNamel():Any = s"$AgentNamel + Overridden"
}

object SecretAgentsl {
	def getName(x:SecretAgentsl) = x.AgentNamel
	def setname(x:SecretAgentsl,newname:String) = { x.AgentNamel = newname}
}



object r1 extends App {

	val Ashish = new SecretAgentsl("Ashish")
	println(SecretAgentsl.getName(Ashish))
	
	SecretAgentsl.setname(Ashish,"Ashish Tripathi")
	println(SecretAgentsl.getName(Ashish))
	
}


