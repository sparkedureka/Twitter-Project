class CommonMan(val name:String, private val superhero:String)

object CommonMan {
	def showMeInnerSecret(x:CommonMan) = x.superhero
}

object SuperRunner extends App {

	val Anil = new CommonMan("Anil","SUPERMAN")
	val Shweta = new CommonMan("Shweta","CATWOMAN")
	val Arvind = new CommonMan("Arvind","HANCOCK")
	
	println(Anil.name + " is The " + CommonMan.showMeInnerSecret(Anil))
	println(Shweta.name + " is The " + CommonMan.showMeInnerSecret(Shweta))
	println(Arvind.name + " is The " + CommonMan.showMeInnerSecret(Arvind))
	println(Arvind.name + " is The " + Arvind.superhero)
}
