import scala.beans.BeanProperty

object TestPerson2 extends App {
       val Virat = new Person2("Virat Kohli",27)                
       println(Virat.Name + " is of Age " + Virat.Age + " and he is a " + Virat.Title)
       println(Virat.Name + " is of Age " + Virat.Age + " and he is a " + Virat.Title + " who loves " + Virat.Hobbies)

      val Yuvraj = new Person2("Yuvraj Singh",30,"Batsman")
      println(Yuvraj.Name + " is of Age " + Yuvraj.Age + " and he is a " + Yuvraj.Title + " who loves " + Yuvraj.Hobbies)	
}

class Person2(@BeanProperty val Name:String,
	      @BeanProperty var Age:Int,
       	      val Title:String,
	      val Hobbies:String) {
      def this(Name:String,Age:Int,Title:String) = this(Name:String,Age:Int,Title:String,"Bollywood Movies")
      def this(Name:String,Age:Int) = this(Name:String,Age:Int,"Sports Person")	
}
















