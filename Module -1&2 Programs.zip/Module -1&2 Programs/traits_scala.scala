trait logger {
	def log(msg:String) //an abstract method
}

class ConsoleLogger extends logger
	with Cloneable with Serializable {
		def log(msg:String) = println(msg)
}


trait TimeStampLogger extends logger {
	abstract override def log(msg:String) {
		super.log(new java.util.Date() + " " + msg)
	}
}

trait ShortLogger extends ConsoleLogger {
	val maxlength = 15
	override def log(msg:String) {
		super.log(if (msg.length <= maxlength) msg else msg.substring(0,maxlength - 3) + "... ")
	}
}

object traitsrunner extends App {
	val server = new ConsoleLogger with ShortLogger 
	server.log("Cluster is going down")

	val server2 = new ConsoleLogger with TimeStampLogger;
	server2.log("Cluster is going down");

	val server3 = new ConsoleLogger
	server3.log("Cluster is going down")

	val server4 = new ConsoleLogger with TimeStampLogger with ShortLogger 
        server4.log("Cluster is going down")

}
