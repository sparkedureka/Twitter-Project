println("Welcome to the script world of scala")
