class TestScalaNew {
	def main(Args:Array[String]):Unit = {
		val Andrew = new PersonScala("Andrew",25)
		println(Andrew.age)
		println(Andrew.name)
		Andrew.name = "Andrew Fintoff"
		println(Andrew.name)
	}
}

class PersonScala(var name:String, var age:Int)

