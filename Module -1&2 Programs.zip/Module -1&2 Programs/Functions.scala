//1val anon1:Function1[Int,Int] = new Function1[Int,Int] {
//	def apply(x:Int) = x*x
//1}

//1val anon1 = new Function1[Int,Int] {
//      def apply(x:Int) = x*x
//1}

val anon1 = (x:Int) => x*x

//2val anon2:Function2[Int,Int,Int] = new Function2[Int,Int,Int] {
//	def apply(x:Int,y:Int) = x*y
//2}

//2val anon2 = new Function2[Int,Int,Int] {
//	def apply(x:Int,y:Int) = x*y
//2}

val anon2 = (x:Int,y:Int) => x*y

println(anon1(9))
println(anon2(2,3))
