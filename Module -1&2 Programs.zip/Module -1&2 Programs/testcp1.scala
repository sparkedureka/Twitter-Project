class emp (val _name:String) {
	def name = _name + " Tripathi"

}	 

object f extends App {
	val Ashish = new emp("Ashish")
	println(Ashish.name)
	println(Ashish._name)

}
