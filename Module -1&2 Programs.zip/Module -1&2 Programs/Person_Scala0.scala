class TestScala1 {
    def main(Args:Array[String]) {
        Person Andrew = new Person("Andrew",25);
        System.out.println(Andrew.getAge());
        System.out.println(Andrew.getName());
        Andrew.setName("Andrew hudson");
        System.out.println(Andrew.getName());
    }
}


class Person1(val Name:String, var Age:Int) {
        def setAge_(Age1:Int) = {
                if (Age1 > Age) Age = Age1;
        }
}
































