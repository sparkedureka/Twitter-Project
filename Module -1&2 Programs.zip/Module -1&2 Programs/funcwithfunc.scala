object funcwithfunc extends App {
//	val f(Int,Int => Int) => Int = (x:Int,y:Int => Int) => y(x) //Function Declaration standard way
        val f = (x:Int,y:Int => Int) => y(x) //Crispier way possible due to type inference

	println(f(3, (m:Int) => m + 1)) //Declaration Type 1, (m:Int) => m + 1) is an example of anonymous function

//	println(f(3, m => m + 1)) //Declaration type 2, as we can remove int from declaration as it can be inferred

//	println(f(3, _ + 1)) //Declaration type 3 with place holder _.

//      println(f(3, 1 + _)) //Declaration type 4 as a + b = b + a.

//Function returning a function

	val g = (x:Int) => (y:Int) => y + x //Function g takes an Int but gives out a function y which returns an Int

	println(g(4)(5)) 
	
	println(g.apply(4).apply(5)) //This is also called currying, magic apply can be used here as its what internally it calls into




}
