//Sum of all results between two numbers (including the numbers) having a function applied on each number 

//SUM of FACTORIALS BETWEEN TWO NUMBERS INCLUDING THE TWO NUMBERS
//-----------------------------------------------------------------
def fact(x:Int):Int = if (x == 0) 1 else x*fact(x-1) //Function performing factorial of a number

def sumFactorials(x:Int,y:Int):Int = sum(fact,x,y) //Function which calls sum function with a function which takes an INT and gives an INT

//SUM of CUBES BETWEEN TWO NUMBERS INCLUDING THE TWO NUMBERS
//-----------------------------------------------------------------
def cube(x:Int):Int = x*x*x //Function calculating a cube of a number

def sumCubes(x:Int,y:Int):Int = sum(cube,x,y) //Function which calls sum function with a function which takes an INT and gives an INT

//SUM of ALL Numbers BETWEEN TWO NUMBERS INCLUDING THE TWO NUMBERS
//-----------------------------------------------------------------
def id(x:Int):Int = x //Function calculating a cube of a number

def sumInts(x:Int,y:Int):Int = sum(id,x,y) //Function which calls sum function with a function which takes an INT and gives an INT

//GENERIC SUM FUNCTION WHICH SUMS UP ALL NUMBERS BETWEEN TWO NUMBERS INCLUDING THE TWO NUMBERS HAVING APPLIED A FUNCTION APPLIED ON EACH ONE OF THEM
//--------------------------------------------------------------------------------------------------------------------------------------------------
def sum(f:Int => Int,a:Int,b:Int):Int = if (a > b) 0 else f(a) + sum(f,a+1,b) 





//Calling methods
println(sumFactorials(6,7))
println(sumCubes(3,9))
println(sumInts(4,10))
