println("SCALA in a Nut....Shell-----> Script ")
def areacircle(x:Int) = 3.14*x*x

println(areacircle(4))	
