import scala.math.random

import org.apache.spark._
import org.apache.hadoop.io._

/** Computes an approximation to pi */
object SparkPi {
  def main(args: Array[String]) {
    val conf = new SparkConf().setAppName("Spark Pi").setMaster("spark://localhost.localdomain:7077")
    val spark = new SparkContext(conf)
    val slices = if (args.length > 0) args(0).toInt else 2
    val n = math.min(100000L * slices, Int.MaxValue).toInt // avoid overflow
    val count = spark.parallelize(1 until n, slices).map { i =>
      val x = random * 2 - 1
      val y = random * 2 - 1
      if (x*x + y*y < 1) 1 else 0
    }.reduce(_ + _)
    
    //Saving Sequenced data into HDFS
    val save_data = spark.parallelize(List(("Hadoop",3),("Spark",2),("Hbase",2)), 2)
    save_data.saveAsSequenceFile("Output")
    
    val ab = Map("Sarthak" -> 2,"Vishwa" -> 10, "Triveni" -> 5,"Shiva" -> 6)
    
    //Reading Sequenced data from HDFS
    val get_save_data = spark.sequenceFile("hdfs://localhost:8020/user/edureka/Output",classOf[Text],classOf[IntWritable]).map{case (x,y) => (x.toString,y.get())}
    get_save_data.collect().foreach(println)
    
    println("Pi is roughly " + 4.0 * count / n)
    spark.stop()
  }
}