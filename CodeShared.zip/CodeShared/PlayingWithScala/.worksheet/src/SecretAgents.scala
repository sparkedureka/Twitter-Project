class SecretAgents(val AgentName:String) {
        def shoot(Name:String,n:Int) = {
                SecretAgents.decrementbullets(n)
                println("Agent " + Name + " shot " + n + " bullets!")
        }
}

object SecretAgents {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(272); 
        private var bullets = 3000;System.out.println("""bullets  : Int = """ + $show(bullets ));$skip(109); 
        private def decrementbullets(count:Int) = if (bullets - count <= 0) bullets = 0 else bullets-= count;System.out.println("""decrementbullets: (count: Int)Unit""");$skip(38); 

        def currentbullets = bullets;System.out.println("""currentbullets: => Int""")}
}

object SecretAgentsRunner extends App {
        println("Bullets in the Secret Coffer: " + SecretAgents.currentbullets)
        val Bond    = new SecretAgents("James Bond")
        val Leitner = new SecretAgents("Felix Leitner")
        val Bourne  = new SecretAgents("Jason Bourne")
        val _99     = new SecretAgents("Agent 99")
        val Max     = new SecretAgents("Smart Max")

        Bond.shoot(Bond.AgentName,300)
        Leitner.shoot(Leitner.AgentName,500)
        Bourne.shoot(Bourne.AgentName,200)
        _99.shoot(_99.AgentName,200)
        Max.shoot(Max.AgentName,100)

        println("Bullets left with the Secret Agency are: " + SecretAgents.currentbullets)
}
