package main

object playwork {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(75); 
  println("Welcome to the Scala worksheet");$skip(30); 
  
  val a = Array(1,2,3,4,5);System.out.println("""a  : Array[Int] = """ + $show(a ));$skip(23); val res$0 = 
  
  a.map(x => x + 1);System.out.println("""res0: Array[Int] = """ + $show(res$0))}
  
  
}
