import org.apache.spark.mllib.recommendation.ALS
import org.apache.spark.mllib.recommendation.Rating
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.rdd._
import org.apache.log4j.{Level, Logger} //this is to suppress INFO logs on the console


object MovieLensALS {

def main(args: Array[String]) {

val conf = new SparkConf().setAppName("MovieLensALS").setMaster("local[2]")

val sc = new SparkContext(conf)


//this is to limit console logging to errors only
val rootLogger = Logger.getRootLogger()
rootLogger.setLevel(Level.ERROR)

val rawData = sc.textFile("file:///home/edureka/ml-100k/u.data")

println(rawData.first())

val rawRatings = rawData.map(_.split("\t").take(3))

println(rawRatings.first())

val ratings = rawRatings.map {case Array(user,movie,rating) => Rating(user.toInt,movie.toInt,rating.toDouble)}

println(ratings.first())

//train the data with one of the very popular algorithms based on collaborative filtering 
//approach called Alternating Least Squares or ALS

//here, train method takes in a Rating RDD in which is in the form (userID, productID, rating) pairs. 
//We approximate the ratings matrix as the product of two lower-rank matrices of a given rank (number of features). 
//To solve for these features, we run a given number of iterations of ALS. 
//The level of parallelism is determined automatically based on the number of partitions in ratings.
//Parameters:
//ratings - RDD of (userID, productID, rating) pairs
//rank - number of features to use
//iterations - number of iterations of ALS (recommended: 10-20)
//lambda - regularization factor (recommended: 0.01)

val model = ALS.train(ratings, 50, 5, 0.01) 


//model.userFeatures

println(model.userFeatures.count)

println(model.productFeatures.count)

val predictedRating = model.predict(789, 123)

println(predictedRating)

val userId = 789
val K = 10
val topKRecs = model.recommendProducts(userId, K)

println(topKRecs.mkString("\n"))


val movies = sc.textFile("file:///home/edureka/ml-100k/u.item")
val titles = movies.map(line => line.split("\\|").take(2)).map(array => (array(0).toInt,array(1))).collectAsMap()
titles(123)

val moviesForUser = ratings.keyBy(_.user).lookup(789)

println(moviesForUser.size)

moviesForUser.sortBy(-_.rating).take(10).map(rating => (titles(rating.product), rating.rating)).foreach(println)

}

}